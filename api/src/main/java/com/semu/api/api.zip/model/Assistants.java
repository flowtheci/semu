package com.semu.api.model;

public enum Assistants {
    MathAssistant,
    MathVisionAssistant,
    TitleAssistant,
    EstonianAssistant
}
